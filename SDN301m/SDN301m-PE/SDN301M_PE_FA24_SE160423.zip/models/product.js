const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    productName: { type: String, require: true, unique: true },
    productDescription: { type: String, require: true },
    image: { type: String, require: true },
    price: { type: Number, require: true, min: 0, max: 9999 },
    isFeature: { type: Boolean, default: false },
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
      require: true,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Product", productSchema);
