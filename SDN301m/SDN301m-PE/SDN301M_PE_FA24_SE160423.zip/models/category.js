const mongoose = require("mongoose");

const categorySchema = new mongoose.Schema(
  {
    categoryName: { type: String, require: true, unique: true },
    categoryDescription: { type: String, require: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Category", categorySchema);
