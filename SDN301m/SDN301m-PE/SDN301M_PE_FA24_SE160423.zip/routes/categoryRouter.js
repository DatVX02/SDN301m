const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const categoryController = require("../controllers/categoryController");

router.post("/login", categoryController.Login);

const validateToken = async (req, res, next) => {
  try {
    let token;
    let authHeader = req.headers.authorization || req.headers.Authorization;
    if (authHeader && authHeader.startsWith("Bearer")) {
      token = authHeader.split(" ")[1];
      jwt.verify(token, "SDN301M_PE_FA24_SE160423", (err, decoded) => {
        if (err) {
          res.status(401).json({ error: "Sai email hoặc mật khẩu!" });
        }
        req.user = decoded.user;
        next();
      });
      if (!token) {
        res.status(401).json({
          error: "Người dùng không được ủy quyền hoặc mã thông báo bị thiếu",
        });
      }
    } else {
      res.status(401).json({ error: "Thiếu mã thông báo truy cập!" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

router.use(validateToken);

router.post("/", categoryController.createCategory);

router.get("/", categoryController.getCategories);

router.get("/:id", categoryController.getCategoryById);

router.put("/:id", categoryController.updateCategory);

router.delete("/:id", categoryController.deleteCategory);

module.exports = router;
