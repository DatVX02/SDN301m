const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const product = require("../models/product");
const category = require("../models/category");

const verifyToken = (req, res, next) => {
  const token = req.cookies["access_token"];
  if (!token) return res.redirect("/auth/login");

  jwt.verify(token, "SDN301M_PE_FA24_SE160423", (err, user) => {
    if (err) {
      if (err instanceof jwt.TokenExpiredError) {
        return res.redirect("/auth/login");
      } else {
        return res.status(403).json({
          message:
            "Truy cập bị từ chối: Mã truy cập không hợp lệ hoặc đã hết hạn",
        });
      }
    }
    req.user = user;
    next();
  });
};
router.use(verifyToken);

router.get("/", async (req, res) => {
  try {
    const products = await product.find().populate("category");
    res.render("dashboard", { products });
  } catch (error) {
    res.status(400).send(error.message);
  }
});

router.get("/delete/:id", async (req, res) => {
  try {
    await product.findByIdAndDelete(req.params.id);
    res.redirect("/dashboard");
  } catch (error) {
    res.status(400).send(error.message);
  }
});

router.get("/get-category-for-create-product", async (req, res) => {
  const categories = await category.find();
  res.render("newProduct", { categories });
});

router.post("/create", async (req, res) => {
  try {
    const { productName, productDescription, price, image, category } =
      req.body;

    const isFeature = req.body.isFeature === "on";
    const newProduct = new product({
      productName,
      productDescription,
      price,
      image,
      isFeature,
      category,
    });
    await newProduct.save();
    res.redirect("/dashboard");
  } catch (error) {
    res.status(400).send(error.message);
  }
});

router.get("/get-category-for-edit-product/:id", async (req, res) => {
  try {
    const item = await product.findById(req.params.id);
    const categories = await category.find();
    res.render("editProduct", { product: item, categories: categories });
  } catch (error) {
    res.status(400).send(error.message);
  }
});

router.post("/edit/:id", async (req, res) => {
  try {
    const {
      productName,
      productDescription,
      price,
      image,
      isFeature,
      category,
    } = req.body;
    await product.findByIdAndUpdate(req.params.id, {
      productName,
      productDescription,
      price,
      image,
      isFeature,
      category,
    });
    res.redirect("/dashboard");
  } catch (error) {
    res.status(400).send(error.message);
  }
});
module.exports = router;
