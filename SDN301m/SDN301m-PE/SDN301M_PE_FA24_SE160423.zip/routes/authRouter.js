const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const user = require("../models/user");
const router = express.Router();

router.get("/login", async (req, res) => {
  res.render("login");
});

router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).render("login", {
      message: "Tài khoản và mật khẩu không được bỏ trống",
    });
  }
  const account = await user.findOne({ username });

  if (!account) {
    return res
      .status(401)
      .render("login", { message: "Tài khoản không tồn tại" });
  }

  const isMatch = await bcrypt.compare(password, account.password);
  if (!isMatch) {
    return res
      .status(401)
      .render("login", { message: "Mật khẩu không chính xác" });
  }

  const token = jwt.sign(
    { _id: account._id, us: account.username },
    "SDN301M_PE_FA24_SE160423",
    {
      expiresIn: "1h",
    }
  );

  res.cookie("access_token", token);

  res.redirect("/dashboard");
});

router.get("/register", async (req, res) => {
  res.render("register");
});
router.post("/register", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).render("register", {
      message: "Tài khoản và mật khẩu không được bỏ trống",
    });
  }
  const account = await user.findOne({
    username,
  });
  if (account) {
    return res
      .status(400)
      .render("register", { message: "Tài khoản đã tồn tại" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser = new user({
    username,
    password: hashedPassword,
  });
  await newUser.save();
  res.redirect("/auth/login");
});

router.get("/logout", (req, res) => {
  res.clearCookie("access_token");
  res.redirect("/auth/login");
});

module.exports = router;
