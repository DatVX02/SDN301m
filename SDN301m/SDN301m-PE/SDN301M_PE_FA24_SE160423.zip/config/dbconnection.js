const mongoose = require("mongoose");
function connect() {
  const connect = mongoose.connect(
    "mongodb://127.0.0.1:27017/SDN301M_PE_FA24_SE160423DB"
  );
  connect.then((db) => {
    console.log("ok!!!!");
  });
}

module.exports = { connect };
