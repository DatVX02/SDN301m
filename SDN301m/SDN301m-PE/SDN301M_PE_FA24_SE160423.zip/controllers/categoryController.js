const Category = require("../models/category");
const User = require("../models/user");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");

exports.Login = async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({
        error: "username and password are required",
      });
    }
    const account = await User.findOne({ username });

    if (!account) {
      return res.status(401).json({ error: "Account not found" });
    }

    const isMatch = await bcrypt.compare(password, account.password);
    if (!isMatch) {
      return res.status(401).json({ error: "Wrong password" });
    }

    const token = jwt.sign(
      { _id: account._id, us: account.username },
      "SDN301M_PE_FA24_SE160423",
      {
        expiresIn: "1h",
      }
    );

    res.status(200).json({ token });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.createCategory = async (req, res) => {
  try {
    const { categoryName, categoryDescription } = req.body;
    if (!categoryName || !categoryDescription) {
      return res
        .status(400)
        .json({ error: "Name and description are required" });
    }
    const checkExist = await Category.findOne({
      categoryName,
    });
    if (checkExist) {
      return res
        .status(200)
        .json({ error: `Category already exists with name ${categoryName}` });
    }
    const category = new Category(req.body);
    await category.save();
    res.status(201).json(category);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.getCategories = async (req, res) => {
  try {
    const categories = await Category.find();
    res.status(200).json(categories);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getCategoryById = async (req, res) => {
  try {
    const category = await Category.findById(req.params.id);
    if (!category) return res.status(404).json({ error: "Category not found" });
    res.status(200).json(category);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateCategory = async (req, res) => {
  try {
    const { categoryName, categoryDescription } = req.body;
    const category = await Category.findById(req.params.id);
    if (!category) return res.status(404).json({ error: "Category not found" });
    if (categoryName) {
      const checkExist = await Category.findOne({
        categoryName,
      });
      if (checkExist) {
        return res
          .status(200)
          .json({ error: `Category already exists with name ${categoryName}` });
      } else {
        category.categoryName = categoryName;
      }
    }
    category.categoryDescription =
      categoryDescription || category.categoryDescription;
    await category.save();
    res.status(200).json(category);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteCategory = async (req, res) => {
  try {
    const category = await Category.findByIdAndDelete(req.params.id);
    if (!category) return res.status(404).json({ error: "Category not found" });
    res.status(200).json({ message: "Category deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
